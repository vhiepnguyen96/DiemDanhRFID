/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.controllers.canbo;

import com.diemdanh.models.canbo.CanBo_Model;
import com.diemdanh.utils.common.TemporaryData;

/**
 *
 * @author chuna
 */
public class CanBo_TemporaryData extends TemporaryData<CanBo_Model> {
    
}
