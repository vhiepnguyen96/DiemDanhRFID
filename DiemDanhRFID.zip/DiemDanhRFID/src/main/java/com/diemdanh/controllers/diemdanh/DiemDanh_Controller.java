/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.controllers.diemdanh;


import com.diemdanh.controllers.login.Login_Controller;
import com.diemdanh.database.DatabaseHandler;

/**
 *
 * @author chuna
 */
public class DiemDanh_Controller {

    private String masukien;
    private String table = "DiemDanh";
    private DatabaseHandler handler = Login_Controller.handler;

    public DiemDanh_Controller() {

    }

    public void diemDanhCBVao() {
    }

    public void diemDanhCBRa() {

    }

    public void add_ThanhVien() {

    }
}
