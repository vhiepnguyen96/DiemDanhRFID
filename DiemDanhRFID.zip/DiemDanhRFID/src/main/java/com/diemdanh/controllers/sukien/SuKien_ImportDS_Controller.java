/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.controllers.sukien;

import com.diemdanh.models.canbo.CanBo_Model;
import com.diemdanh.models.canbothamgia.DSCanBo_Model;
import com.diemdanh.models.sinhvien.SinhVien_Model;
import com.diemdanh.models.sinhvienthamgia.DSSinhVien_Model;
import com.diemdanh.utils.common.ConvertUtilities;
import com.diemdanh.utils.common.StorageResults;
import com.diemdanh.utils.other.component.Alert;
import com.diemdanh.views.canbo.CanBo_Table;
import com.diemdanh.views.canbothamgia.DSCanBo_View;
import com.diemdanh.views.sinhvien.SinhVien_Table;
import com.diemdanh.views.sinhvienthamgia.DSSinhVien_View;
import java.awt.Component;
import java.util.ArrayList;
import java.util.HashMap;
import com.diemdanh.views.interfaces.sukien.SuKien_ImportDS_Impl;

/**
 *
 * @author chuna
 */
public class SuKien_ImportDS_Controller {

    SuKien_ImportDS_Impl iSuKien_ImportDS;
    public static Enum NO_REG, NEW, EXISTS;

    public SuKien_ImportDS_Controller(SuKien_ImportDS_Impl iSuKien_ImportDS) {
        this.iSuKien_ImportDS = iSuKien_ImportDS;
    }

    public void checkDuplicateCanBo(ArrayList<CanBo_Model> canBo2DS, String mask) {
        ArrayList<CanBo_Model> canBo_NoInfo = new ArrayList<>();
        ArrayList<DSCanBo_Model> dSCanBo_Moi = new ArrayList<>();
        ArrayList<DSCanBo_Model> dSCBTonTais = new ArrayList<>();
        canBo2DS.forEach((t) -> {
            boolean tonTai = DSCanBo_View.getController().check_CanBoThamGia(t.getMaCB(), mask);
            if (tonTai) {
                dSCBTonTais.add(new DSCanBo_Model(t.getMaCB(), t.getTen()));
            } else {
                boolean check_TonTai = CanBo_Table.getController().check_CanBo(t.getMaCB());
                if (!check_TonTai) {
                    t.setMaRFID("Chưa có");
                    canBo_NoInfo.add(t);
                } else {
                    dSCanBo_Moi.add(new DSCanBo_Model(t.getMaCB(), t.getTen()));
                }
            }
        });
        iSuKien_ImportDS.updateCanBoChuaDK(canBo_NoInfo);
        iSuKien_ImportDS.updateDSCanBoMoi(dSCanBo_Moi);
        iSuKien_ImportDS.updateDSCanBoTonTai(dSCBTonTais);
    }

    public void checkDuplicateSinhVien(ArrayList<SinhVien_Model> sinhVien2DS, String mask) {
        ArrayList<SinhVien_Model> sinhVienChuaDK = new ArrayList<>();
        ArrayList<DSSinhVien_Model> dSSinhVien_Moi = new ArrayList<>();
        ArrayList<DSSinhVien_Model> dSSinhVienTonTai = new ArrayList<>();
        sinhVien2DS.forEach((t) -> {
            boolean tonTai = DSSinhVien_View.getController().check_SinhVienThamGia(t.getMaSV(), mask);
            System.out.println(tonTai);
            if (tonTai) {
                dSSinhVienTonTai.add(new DSSinhVien_Model(t.getMaSV(), t.getTen()));
            } else {
                boolean check_TonTai = SinhVien_Table.getController().check_SinhVien(t.getMaSV());
                if (!check_TonTai) {
                    t.setMaRFID("Chưa có");
                    sinhVienChuaDK.add(t);
                } else {
                    dSSinhVien_Moi.add(new DSSinhVien_Model(t.getMaSV(), t.getTen()));
                }
            }
        });
        iSuKien_ImportDS.updateSinhVienChuaDK(sinhVienChuaDK);
        iSuKien_ImportDS.updateDSSinhVienMoi(dSSinhVien_Moi);
        iSuKien_ImportDS.updateDSSinhVienTonTai(dSSinhVienTonTai);
    }

    public int addDSCanBoChuaDK(ArrayList<CanBo_Model> canBo_NoInfo, String mask) {
        int countSuccess = 0;
        if (!canBo_NoInfo.isEmpty()) {
            int select = Alert.showQuestionDialog(
                    (Component) iSuKien_ImportDS, "Có " + canBo_NoInfo.size() + " cán bộ chưa có đăng ký thông tin.\n"
                    + "Bạn có muốn thêm vào hệ thống", "Thông báo");
            if (select == Alert.OK) {
                StorageResults add_CanBo = CanBo_Table.getController().add_CanBo(canBo_NoInfo);
                ArrayList<CanBo_Model> success = (ArrayList<CanBo_Model>) add_CanBo.getSuccess();
                ArrayList<CanBo_Model> failure = (ArrayList<CanBo_Model>) add_CanBo.getSuccess();
                iSuKien_ImportDS.updateDSCBTable();
                if (!failure.isEmpty()) {
                    StringBuilder thatBai = new StringBuilder();
                    failure.forEach((t) -> {
                        thatBai.append("Thêm cán bộ có mã ").append(t.getMaCB()).append(" thất bại.\n");
                    });
                    Alert.showMessageDialog((Component) iSuKien_ImportDS, thatBai.toString());
                }
                if (!success.isEmpty()) {
                    countSuccess += addDSCanBoMoi(ConvertUtilities.canBo2DS(canBo_NoInfo), mask);
                }
            }
        }
        return countSuccess;
    }

    public int addDSCanBoMoi(ArrayList<DSCanBo_Model> dSCanBo_Moi, String mask) {
        int countSuccess = 0;
        if (!dSCanBo_Moi.isEmpty()) {
            StorageResults add_canBoThamGia = DSCanBo_View.getController().add_canBoThamGia(dSCanBo_Moi, mask);
            ArrayList<DSCanBo_Model> success = (ArrayList<DSCanBo_Model>) add_canBoThamGia.getSuccess();
            ArrayList<DSCanBo_Model> failure = (ArrayList<DSCanBo_Model>) add_canBoThamGia.getFailure();
            iSuKien_ImportDS.updateDSCBTable();
            if (!failure.isEmpty()) {
                StringBuilder thatBai = new StringBuilder();
                failure.forEach((t) -> {
                    thatBai.append("Thêm cán bộ có mã ").append(t.getMaCB()).append(" vào danh sách tham gia thất bại.\n");
                });
                Alert.showMessageDialog((Component) iSuKien_ImportDS, thatBai.toString());
            }
            if (!success.isEmpty()) {
                countSuccess += success.size();
            }
        }
        return countSuccess;
    }

    public int replaceDSCanBo(ArrayList<DSCanBo_Model> dSCBTonTais, String mask) {
        StorageResults update_canBoThamGia = DSCanBo_View.getController().update_canBoThamGia(dSCBTonTais, mask);
        ArrayList<DSCanBo_Model> success2 = (ArrayList<DSCanBo_Model>) update_canBoThamGia.getSuccess();
        ArrayList<DSCanBo_Model> failure2 = (ArrayList<DSCanBo_Model>) update_canBoThamGia.getFailure();
        iSuKien_ImportDS.updateDSCBTable();
        if (!failure2.isEmpty()) {
            StringBuilder thatBai = new StringBuilder();
            failure2.forEach((t) -> {
                thatBai.append("Ghi đè cán bộ có mã ").append(t.getMaCB()).append(" thất bại.\n");
            });
            Alert.showMessageDialog((Component) iSuKien_ImportDS, thatBai.toString());
        }
        return success2.size();
    }

    public int addDSSinhVienChuaDK(ArrayList<SinhVien_Model> sinhVien_NoInfo, String mask) {
        int countSuccess = 0;
        StorageResults add_SinhVien = SinhVien_Table.getController().add_SinhVien(sinhVien_NoInfo);
        ArrayList<SinhVien_Model> success = (ArrayList<SinhVien_Model>) add_SinhVien.getSuccess();
        ArrayList<SinhVien_Model> failure = (ArrayList<SinhVien_Model>) add_SinhVien.getFailure();
        if (!failure.isEmpty()) {
            StringBuilder error = new StringBuilder();
            failure.forEach((t) -> {
                error.append("Thêm sinh viên có mã ").append(t.getMaSV()).append(" thất bại.\n");
            });
            Alert.showMessageDialog((Component) iSuKien_ImportDS, error.toString());
        }
        if (!success.isEmpty()) {
            countSuccess += addDSSinhVienMoi(ConvertUtilities.sinhVien2DS(sinhVien_NoInfo), mask);
        }
        return countSuccess;
    }

    public int addDSSinhVienMoi(ArrayList<DSSinhVien_Model> dSSinhVien_Moi, String mask) {
        int countSuccess = 0;
        if (!dSSinhVien_Moi.isEmpty()) {
            StorageResults add_sinhVienThamGia = DSSinhVien_View.getController().add_sinhVienThamGia(dSSinhVien_Moi, mask);
            iSuKien_ImportDS.updateDSSVTable();
            ArrayList<SinhVien_Model> success = (ArrayList<SinhVien_Model>) add_sinhVienThamGia.getSuccess();
            ArrayList<SinhVien_Model> failure = (ArrayList<SinhVien_Model>) add_sinhVienThamGia.getFailure();
            if (!failure.isEmpty()) {
                StringBuilder thatBai = new StringBuilder();
                failure.forEach((t) -> {
                    thatBai.append("Thêm sinh viên có mã ").append(t.getMaSV()).append(" vào danh sách tham gia thất bại.\n");
                });
                Alert.showMessageDialog((Component) iSuKien_ImportDS, thatBai.toString());
            }
            if (!success.isEmpty()) {
                countSuccess += success.size();
            }
        }
        return countSuccess;
    }

    public int replaceDSSinhVien(ArrayList<DSSinhVien_Model> dSSVTonTai, String mask) {
        StorageResults update_sinhVienThamGia = DSSinhVien_View.getController().update_sinhVienThamGia(dSSVTonTai, mask);
        ArrayList<DSSinhVien_Model> success2 = (ArrayList<DSSinhVien_Model>) update_sinhVienThamGia.getSuccess();
        ArrayList<DSSinhVien_Model> failure2 = (ArrayList<DSSinhVien_Model>) update_sinhVienThamGia.getFailure();
        iSuKien_ImportDS.updateDSCBTable();
        if (!failure2.isEmpty()) {
            StringBuilder thatBai = new StringBuilder();
            failure2.forEach((t) -> {
                thatBai.append("Ghi đè sinh viên có mã ").append(t.getMaSV()).append(" thất bại.\n");
            });
            Alert.showMessageDialog((Component) iSuKien_ImportDS, thatBai.toString());
        }
        return success2.size();
    }

}
