/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.controllers.sinhvien;

import com.diemdanh.models.sinhvien.SinhVien_Model;
import com.diemdanh.utils.common.TemporaryData;

/**
 *
 * @author chuna
 */
public class SinhVien_TemporaryData extends TemporaryData<SinhVien_Model> {

    

}
