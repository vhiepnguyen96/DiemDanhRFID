/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.models.login;

/**
 *
 * @author chuna
 */
public class User {

    private String taiKhoan;
    private String matKhau;
    private boolean ghiNho;

    public User(String taiKhoan, String matKhau) {
        this.taiKhoan = taiKhoan;
        this.matKhau = matKhau;
    }

    public User(String taiKhoan, String matKhau, boolean ghiNho) {
        this.taiKhoan = taiKhoan;
        this.matKhau = matKhau;
        this.ghiNho = ghiNho;
    }

    public String getTaiKhoan() {
        return taiKhoan;
    }

    public void setTaiKhoan(String taiKhoan) {
        this.taiKhoan = taiKhoan;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    public boolean isGhiNho() {
        return ghiNho;
    }

    public void setGhiNho(boolean ghiNho) {
        this.ghiNho = ghiNho;
    }

}
