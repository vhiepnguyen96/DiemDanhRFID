/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.utils.constant;

/**
 *
 * @author chuna
 */
public class Constant {

    public static final String LOGGER_LAUNCH = "LAUCH";
    public static final String LOGGER_LOGIN = "Login";
    public static final String LOGGER_LOGOUT = "logout";
    public static final String LOGGER_CLOSE = "Close app";
    public static final String LOGGER_DIEMDANH = "Attendence";
    public static final String LOGGER_IMPORT_CANBO = "Import teacher";
    public static final String LOGGER_IMPORT_CANBOTHAMGIA = "Import teacher invited";
    public static final String LOGGER_IMPORT_SINHVIEN = "Import student";
    public static final String LOGGER_IMPORT_SINHVIENTHAMGIA = "Import student invited";
    public static final String LOGGER_IMPORT_SUKIEN = "Import event";
    public static final String LOGGER_ADD_CANBO = "Add teacher";
    public static final String LOGGER_ADD_CANBOTHAMGIA = "Add teacher to event";
    public static final String LOGGER_ADD_SINHVIEN = "Add student";
    public static final String LOGGER_ADD_SINHVIENTHAMGIA = "Add student to event";
    public static final String LOGGER_ADD_SUKIEN = "Add event";
    public static final String LOGGER_UPDATE_CANBO = "Update teacher";
    public static final String LOGGER_UPDATE_CANBOTHAMGIA = "Update teacher of event";
    public static final String LOGGER_UPDATE_SINHVIEN = "Update student";
    public static final String LOGGER_UPDATE_SINHVIENTHAMGIA = "Update student of event";
    public static final String LOGGER_UPDATE_SUKIEN = "Update event";
    public static final String LOGGER_DELETE_CANBO = "Delete teacher";
    public static final String LOGGER_DELETE_CANBOTHAMGIA = "Delete teacher from event";
    public static final String LOGGER_DELETE_SINHVIEN = "Delete student";
    public static final String LOGGER_DELETE_SINHVIENTHAMGIA = "Delete student from event";
    public static final String LOGGER_DELETE_SUKIEN = "Delete event";

    public static final String LOGGER_PATH = "src/main/resources/log/DiemDanh.log";
    public static final String APP = "Điểm Danh";
    public static final String HOME = "  Trang chủ";
    public static final String CADRE = "  Quản lý Cán bộ";
    public static final String STUDENT = "  Quản lý Sinh viên";
    public static final String EVENT = "  Quản lý Sự kiện";
    public static final String CHECK = "  Điểm danh";
    public static final String REGISTOR = "  Đăng ký";
    public static final String REPORT = "  Thống kê";
    public static final String TURNLOGIN = "  Quản lý Đăng nhập";
    public static final String ABOUT = "  Giới thiệu";
    public static final String ACCOUNT = "  Quản lý tài khoản";
    public static final String LOGOUT = "  Đăng xuất";
    public static final String EXIT = "  Thoát";
    public static final String SETTING = "  Thiết lập";

    public static final String NO_CHANGED = "Đóng";
    public static final String INSERTED = "Thêm";
    public static final String UPDATED = "Cập nhật";

    public static final String ADD_CANBO = "ADD_CANBO";
    public static final String DELETE_CANBO = "DELETE_CANBO";
    public static final String UPDATE_CANBO = "UPDATE_CANBO";

    public static final String ADD_SINHVIEN = "ADD_SINHVIEN";
    public static final String DELETE_SINHVIEN = "DELETE_SINHVIEN";
    public static final String UPDATE_SINHVIEN = "UPDATE_SINHVIEN";

    public static final int VIEW = 0;
    public static final int ADD = 1;
    public static final int UPDATE = 2;
    public static final int DELETE = 3;
    public static final int DIEMDANHVAO = 1;
    public static final int DIEMDANHRA = 2;
    public static final String[] CBOX_REPORT = new String[]{"Tất cả",
        "---------------------",
        "Có mặt", "Vắng mặt(có đăng ký)", "Vắng mặt(không có đăng ký)", "Đi trễ",
        "---------------------",
        "Điểm danh bằng máy", "Điểm danh thủ công"};
    public static final String[] CBOX_DIEMDANH = new String[]{"Tất cả", "---------------------",
        "Chưa đăng ký thẻ", "Đã đăng ký thẻ"};
    public static final String[] cboxXem = new String[]{"Tất cả", "---------------------",
        "Chưa đăng ký thẻ", "Đã đăng ký thẻ"};
    public static final String[] itemCbxSinhVien = {"Tất cả",
        "---------------------",
        "Chưa đăng ký thẻ", "Đã đăng ký thẻ"};
    public static final String[] itemCbxCanBo = itemCbxSinhVien;
    public static final String[] itemCbxSuKien = {"Tất cả",
        "---------------------",
        "Bắt buộc", "Không bắt buộc", "---------------------",
        "Chưa điểm danh", "Đã điểm danh"};
    public static final String[] itemCbxDiemDanh = {"Tất cả",
        "---------------------",
        "Bắt buộc", "Không bắt buộc"};
    public static final String[] itemCbxThongKe = {"Tất cả",
        "---------------------",
        "Bắt buộc", "Không bắt buộc"};
}
