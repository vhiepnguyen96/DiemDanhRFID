/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.utils.common;

import com.administrator.models.log.Log_Model;
import com.diemdanh.utils.constant.Constant;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import org.apache.log4j.SimpleLayout;

/**
 *
 * @author chuna
 */
public class LoggerUtilities {

    private final static Logger logger = Logger.getLogger("DiemDanh");

    static {
        try {
            FileAppender fh = new FileAppender(new SimpleLayout(), Constant.LOGGER_PATH);
            logger.addAppender(fh);
        } catch (IOException | SecurityException ex) {
        }
    }

    public static void log(Priority level, Log_Model log_Model, Throwable throwable) {
        logger.log(level, log_Model.toString(), throwable);
    }

    public static void info(Log_Model msg) {
        logger.info(msg.toString());
    }

    public static void warn(Log_Model msg) {
        logger.warn(msg.toString());
    }

    public static void error(Log_Model msg) {
        logger.error(msg.toString());
    }

    public static String readLogger() {
        String readFromFile = new ReadFile().getContentFile(Constant.LOGGER_PATH);
        return readFromFile;
    }

    public static boolean deleteLoggerFile() {
        File file = new File(Constant.LOGGER_PATH);
        if (file.canRead()) {
            try (PrintWriter writer = new PrintWriter(file)) {
                writer.print("");
                return true;
            } catch (FileNotFoundException ex) {
                LoggerUtilities.error(new Log_Model("CLEAR LOG", "Xóa tất cả lịch sử thất bại."));
            }
        }
        return false;
    }
}
