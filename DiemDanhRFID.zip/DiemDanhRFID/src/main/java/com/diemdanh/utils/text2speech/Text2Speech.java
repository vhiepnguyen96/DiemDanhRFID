/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.utils.text2speech;

import com.diemdanh.utils.common.StringUtilities;
import com.goebl.david.Response;
import com.goebl.david.Webb;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import org.json.JSONException;
import org.json.JSONObject;

/**
 *
 * @author chuna
 */
public class Text2Speech {

    private final String GENDER = "female";
    private static final String URL_FPT_AI = "http://api.openfpt.vn/text2speech/v4";
    private static final String API_KEY = "cc685f0e03cd480cbc131888a33c7772";
    private String content;

    private static Webb webb;
    private static String linkMp3;

    public Text2Speech() {
        setUp();
    }

    public Text2Speech(String content) {
        this.content = content.toLowerCase().trim();
        setUp();
    }

    private void setUp() {
        Webb.setGlobalHeader("api_key", API_KEY);
        webb = Webb.create();
        webb.setBaseUri(URL_FPT_AI);
    }

    private String initURI() {
        try {
            Response<JSONObject> result = webb.post(URL_FPT_AI).header("speed", -500)
                    .header("voice", GENDER).body(content).ensureSuccess()
                    .asJsonObject();
            JSONObject jsonResult = result.getBody();
            linkMp3 = jsonResult.getString("async");
        } catch (JSONException | com.goebl.david.WebbException e) {
            System.out.println("JSONExeption " + e.getMessage());
        }
        return linkMp3;
    }

    public void playSpeech() {
        String cont = StringUtilities.unAccent(content.replaceAll("\\s+", "-"));
        File file = new File("src/main/resources/sound/" + cont + ".mp3");
        if (isExist(file)) {
            playSpeechLocal(file);
        } else {
            playSpeechOnline();
        }
    }

    public void playSpeechLocal(File file) {
        new Speech(file).play();
    }

    public void playSpeechOnline() {
        SwingUtilities.invokeLater(() -> {
            DownloadSpeech downloadSpeech = new DownloadSpeech(content);
            downloadSpeech.execute();
            downloadSpeech.done();
        });
    }

    public boolean isExist(File soundFile) {
        try {
            FileInputStream fIS = new FileInputStream(soundFile);
        } catch (FileNotFoundException ex) {
            return false;
        }
        return true;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String text) {
        this.content = text.toLowerCase().trim();
    }

    class DownloadSpeech extends SwingWorker<Speech, String> {

        private final String URL;

        public DownloadSpeech(String URL) {
            this.URL = URL;
        }

        @Override
        protected Speech doInBackground() {
            try {
                System.out.println("Online");
                return downloadFile(URL);
            } catch (IOException ex) {
                Logger.getLogger(Text2Speech.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
        }

        @Override
        protected void done() {
            try {
                Speech speech = get();
                speech.play();
            } catch (InterruptedException | ExecutionException ex) {
                Logger.getLogger(Text2Speech.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        protected Speech downloadFile(String content)
                throws MalformedURLException, IOException {
            int failed = 10;
            Speech speech = new Speech();
            File sound = null;
            BufferedInputStream inStream = null;
            FileOutputStream outStream = null;
            Text2Speech text2Speech = new Text2Speech();
            text2Speech.setContent(content);
            try {
                URL fileUrlObj = new URL(text2Speech.initURI());
                inStream = new BufferedInputStream(fileUrlObj.openStream());
                String cont = StringUtilities.unAccent(text2Speech.content.replaceAll("\\s+", "-"));
                sound = new File("src/main/resources/sound/" + cont + ".mp3");
                outStream = new FileOutputStream(sound);
                byte data[] = new byte[1024];
                int count;
                while ((count = inStream.read(data, 0, 1024)) != -1) {
                    outStream.write(data, 0, count);
                }
            } catch (IOException ex) {
                Logger.getLogger(Text2Speech.class.getName()).log(Level.SEVERE, null, ex);;
            } finally {
                if (inStream != null) {
                    inStream.close();
                }
                if (outStream != null) {
                    outStream.close();
                }
            }
            if (sound == null || !sound.canRead()) {
                if (failed >= 0) {
                    return downloadFile(content);
                } else {
                    return null;
                }
            } else {
                speech.setSound(sound);
                return speech;
            }
        }
    }

    public static void main(String[] args) {
        Text2Speech speech = new Text2Speech();
        speech.setContent("Thank you Chung. Goodnight.");
        speech.playSpeech();
    }
}
