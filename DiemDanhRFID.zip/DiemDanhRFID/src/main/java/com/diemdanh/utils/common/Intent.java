/*
 * To change pa license header, choose License Headers in Project Properties.
 * To change pa template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.utils.common;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import com.diemdanh.utils.other.table.PanelTable;
import com.diemdanh.views.login.Login_View;
import java.awt.EventQueue;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 *
 * @author chuna
 */
public class Intent {

    private static final JPanel container = new JPanel(new GridLayout());
    public static DialogCustom dialog = new DialogCustom();

    public static void replace(JPanel pa, JComponent replace) {
        EventQueue.invokeLater(() -> {
            pa.removeAll();
            pa.add(replace);
            pa.validate();
            pa.repaint();
        });
    }

    public static void replace(JPanel pa, JComponent replace, PanelTable table) {
        EventQueue.invokeLater(() -> {
            pa.removeAll();
            pa.add(replace);
            table.executeTable();
            pa.validate();
            pa.repaint();
        });

    }

    public static void replace(JPanel newPane, JPanel oldPane, GroupLayout layout) {
        EventQueue.invokeLater(() -> {
            layout.replace(oldPane, newPane);
        });
    }

    public static int getComponentIndex(Component component) {
        if (component != null && component.getParent() != null) {
            List<Component> asList = Arrays.asList(component.getParent().getComponents());
            List<Component> filter = asList.stream()
                    .filter(com -> component == com)
                    .collect(Collectors.toList());
            int indexOf = asList.indexOf(filter.get(0));
            return indexOf;
        }
        return -1;
    }

    public static void setLocationRelativeTo(Component c) {
        dialog.setLocationRelativeTo(c);
    }

    public static void setLocation(Point p) {
        dialog.setLocation(p);
    }

    public static void setLocation(int x, int y) {
        dialog.setLocation(x, y);
    }

    public static Point getLocation() {
        return dialog.getLocation();
    }

    public static int getWidth() {
        return dialog.getWidth();
    }

    public static Dimension getSize() {
        return dialog.getSize();
    }

    public static void closeDialogBox() {
        if (dialog.isShowing()) {
            dialog.dispose();
        }
    }

    public static void setSize(Dimension dimension) {
        dialog.setPreferredSize(dimension);
        dialog.setSize(dimension);
    }

    public static void setAlwaysOnTop(boolean b) {
        dialog.setAlwaysOnTop(b);
    }

    public static void setWidth(int width) {
        dialog.setSize(new Dimension(width, getSize().height));
    }

    public static void showDialog(JComponent content, String title, ImageIcon icon) {
        EventQueue.invokeLater(() -> {
            dialog.initComponent(title, icon, content);
            dialog.setVisible(true);
        });
    }

    public static void closeOutDialog(boolean close) {
        Intent.dialog.addWindowFocusListener(new WindowAdapter() {
            @Override
            public void windowLostFocus(WindowEvent e) {
                if (close) {
                    closeDialogBox();
                } else {
                    EventQueue.invokeLater(() -> {
                        dialog.setVisible(true);
                    });
                }
            }
        });
    }

    public static void repaint(Container instance) {
        instance.revalidate();
        instance.repaint();
    }

    public static FocusListener closeClickOut(JFrame frame) {
        return new FocusListener() {
            private boolean gained = false;

            @Override
            public void focusGained(FocusEvent e) {
                gained = true;
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (gained) {
                    frame.dispose();
                }
            }
        };
    }

    static class DialogCustom extends JDialog {

        public DialogCustom() {
            super(Login_View.app_View, true);
        }

        public void initComponent(String title, ImageIcon icon, JComponent component) {
            setTitle(title);
            if (icon != null) {
                setIconImage(icon.getImage());
            }
            setLayout(new GridLayout());
            getContentPane().removeAll();
            getContentPane().add(component);
            getContentPane().validate();
            getContentPane().repaint();
            setResizable(false);
            pack();
            setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
            addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
                        dispose();
                    }
                }
            });
            setLocationRelativeTo(Login_View.app_View);
        }
    }

}
