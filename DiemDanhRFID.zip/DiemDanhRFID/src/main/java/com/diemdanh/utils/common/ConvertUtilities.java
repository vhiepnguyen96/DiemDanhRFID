/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.utils.common;

import com.diemdanh.models.canbo.CanBo_Model;
import com.diemdanh.models.canbothamgia.DSCanBo_Model;
import com.diemdanh.models.sinhvien.SinhVien_Model;
import com.diemdanh.models.sinhvienthamgia.DSSinhVien_Model;
import java.util.ArrayList;

/**
 *
 * @author chuna
 */
public class ConvertUtilities {

    public static ArrayList<DSCanBo_Model> canBo2DS(ArrayList<CanBo_Model> canBo_Models) {
        ArrayList<DSCanBo_Model> dsCanBo = new ArrayList<>();
        canBo_Models.forEach((t) -> {
            dsCanBo.add(new DSCanBo_Model(t.getMaCB(), t.getTen()));
        });
        return dsCanBo;
    }

    public static ArrayList<DSSinhVien_Model> sinhVien2DS(ArrayList<SinhVien_Model> sinhVien_Models) {
        ArrayList<DSSinhVien_Model> dsSinhVien = new ArrayList<>();
        sinhVien_Models.forEach((t) -> {
            dsSinhVien.add(new DSSinhVien_Model(t.getMaSV(), t.getTen(), t.getMaRFID()));
        });
        return dsSinhVien;
    }
}
