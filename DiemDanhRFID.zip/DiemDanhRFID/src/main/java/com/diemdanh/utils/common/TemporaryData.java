/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.utils.common;

import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author chuna
 * @param <T>
 */
public class TemporaryData<T> {

    private final HashMap<String, ArrayList<T>> hashMap;
    private final ArrayList<T> temp;

    public TemporaryData() {
        hashMap = new HashMap<>();
        temp = new ArrayList<>();
    }

    public void putTemporaryData(String key, ArrayList<T> temp) {
        hashMap.put(key, temp);
    }

    public ArrayList<T> getTemporaryData(String key) {
        ArrayList<T> list = hashMap.get(key);
        if (list == null) {
            return new ArrayList<>();
        } else {
            return list;
        }
    }

    public void removeTemporaryData(String key) {
        hashMap.remove(key);
    }

    public void clear() {
        hashMap.clear();
    }
}
