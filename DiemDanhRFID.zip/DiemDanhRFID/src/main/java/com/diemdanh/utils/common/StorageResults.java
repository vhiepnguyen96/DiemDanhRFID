/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.utils.common;

import java.util.HashMap;

/**
 *
 * @author chuna
 */
public class StorageResults {

    HashMap results;
    Enum SUCCESS, FAILURE;

    public StorageResults() {
        results = new HashMap();
    }

    public StorageResults(HashMap results) {
        this.results = results;
    }

    public void putSuccess(Object value) {
        results.put(SUCCESS, value);
    }

    public Object getSuccess() {
        return results.get(SUCCESS);
    }

    public void putFailure(Object value) {
        results.put(SUCCESS, value);
    }

    public Object getFailure() {
        return results.get(FAILURE);
    }

    public HashMap getResults() {
        return results;
    }
}
