/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.utils.text2speech;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.Player;

/**
 *
 * @author chuna
 */
public class Speech {

    private File sound;

    public Speech() {
    }

    public Speech(File file) {
        sound = file;
    }

    public File getSound() {
        return sound;
    }

    public void setSound(File sound) {
        this.sound = sound;
    }

    public void play() {
        new Thread(() -> {
            try {
                FileInputStream fis = new FileInputStream(getSound());
                BufferedInputStream bis = new BufferedInputStream(fis);
                try {
                    final Player soundPlayer = new Player(bis);
                    soundPlayer.play();
                } catch (JavaLayerException e) {
                }
            } catch (FileNotFoundException ex) {
                System.out.println("File not found: " + ex.getMessage());
            }
        }).start();
    }

}
