/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.views.interfaces.sinhvien;

import com.diemdanh.models.sinhvien.SinhVien_Model;
import com.diemdanh.views.interfaces.View_Impl;

/**
 *
 * @author chuna
 */
public interface SinhVien_View_Impl extends View_Impl<SinhVien_Model> {

}
