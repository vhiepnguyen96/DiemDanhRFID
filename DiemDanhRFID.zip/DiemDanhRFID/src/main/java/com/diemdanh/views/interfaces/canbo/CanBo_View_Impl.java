/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.views.interfaces.canbo;

import com.diemdanh.models.canbo.CanBo_Model;
import com.diemdanh.views.interfaces.View_Impl;

/**
 *
 * @author chuna
 */
public interface CanBo_View_Impl extends View_Impl<CanBo_Model> {
}
