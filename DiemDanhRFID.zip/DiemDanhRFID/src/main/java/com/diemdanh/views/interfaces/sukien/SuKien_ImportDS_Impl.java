/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.views.interfaces.sukien;

import com.diemdanh.models.canbo.CanBo_Model;
import com.diemdanh.models.canbothamgia.DSCanBo_Model;
import com.diemdanh.models.sinhvien.SinhVien_Model;
import com.diemdanh.models.sinhvienthamgia.DSSinhVien_Model;
import java.util.ArrayList;

/**
 *
 * @author chuna
 */
public interface SuKien_ImportDS_Impl {

    void updateCanBoChuaDK(ArrayList<CanBo_Model> canBoChuaDK);

    void updateDSCanBoTonTai(ArrayList<DSCanBo_Model> dSCanBoTonTai);

    void updateDSCanBoMoi(ArrayList<DSCanBo_Model> dSCanBoMoi);

    void updateSinhVienChuaDK(ArrayList<SinhVien_Model> sinhVienChuaDK);

    void updateDSSinhVienTonTai(ArrayList<DSSinhVien_Model> dSSinhVienTonTai);

    void updateDSSinhVienMoi(ArrayList<DSSinhVien_Model> dSSinhVienMoi);

    void updateDSSVTable();

    void updateDSCBTable();

}
