/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.views.interfaces;

import java.util.ArrayList;

/**
 *
 * @author chuna
 * @param <T>
 */
public interface View_Impl<T> {

    void updateTemporaryData(String key, ArrayList<T> temporaryData);

    void importFromExcel();

    void toggleCollapse();

    void updateRowSelected(ArrayList<Integer> list);

    void updateTable();

    void addRow(T cbm);

    void updateRow(T cb);
}
