/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.diemdanh.views.sinhvien;

import com.diemdanh.controllers.sinhvien.SinhVien_Controller;
import com.diemdanh.models.sinhvien.SinhVien_Model;
import com.diemdanh.models.sinhvienthamgia.DSSinhVien_Model;
import com.diemdanh.utils.constant.Constant;
import com.diemdanh.utils.other.component.FormatTextField;
import com.diemdanh.utils.other.table.CustomTable;
import com.diemdanh.utils.other.table.PanelTable;
import com.diemdanh.utils.resources.Resources;
import com.diemdanh.views.interfaces.sinhvien.SinhVien_View_Impl;

import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Hiep_Nguyen
 */
public class SinhVien_Table extends javax.swing.JPanel {

    private String[] columnNames = {"Tất cả", "MSCB", "Họ tên", "Email", "Lớp", "Ngành", "Khoa", "Niên Khóa", "Mã RFID"};
    private static SinhVien_Controller controller;
    private boolean checkBox = false, initCombo = false;
    private PanelTable paneTable;
    private static ArrayList<SinhVien_Model> sinhVienLoad = new ArrayList<>();
    private ArrayList<SinhVien_Model> listSelectedRows = new ArrayList<>();
    private static int click = 0;
    private SinhVien_View_Impl sinhVien_View_Impl;

    public SinhVien_Table(SinhVien_View_Impl sinhVien_View_Impl) {
        controller = new SinhVien_Controller(sinhVien_View_Impl);
        this.sinhVien_View_Impl = sinhVien_View_Impl;
        initComponents();
        createUI();
        loadData();
    }

    private void createUI() {
        btn_TimKiem.setIcon(Resources.search_Icon);
        String[] aModel = Constant.itemCbxSinhVien;
        cbxFilter.removeAllItems();
        Arrays.asList(aModel).forEach((t) -> {
            cbxFilter.addItem(t);
        });
        cbxFilter.setMaximumRowCount(cbxFilter.getModel().getSize());
        txt_TimKiem.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                paneTable.getComboBoxItem().setSelectedIndex(0);
                paneTable.initFilterAndButtons();
            }

        });
    }

    public void loadData() {
        sinhVienLoad = controller.load_SinhVien();
        paneTable = new PanelTable(SinhVien_Controller.array2Object(sinhVienLoad), columnNames);
        paneTable.getPanel().add(pnl_CbxFilter);
        paneTable.getPanel().add(pnl_Search);
        paneTable.getTable().setCheckBox(0);
        paneTable.getTable().setWidth(0, 40);

        cbxFilter.addItemListener((e) -> {
            String typeView = cbxFilter.getModel().getSize() < 1 ? "Tất cả" : cbxFilter.getSelectedItem().toString();
            sinhVienLoad = selectTypeView(typeView);
            setDataTable(SinhVien_Controller.array2Object(sinhVienLoad));
            initCombo = true;
        });
        paneTable.getTable().setCheckBox(0);
        paneTable.getTable().setWidth(0, 60);
        paneTable.getTable().setWidth(1, 60);
        paneTable.getTable().setWidth(2, 120);
        paneTable.getTable().setWidth(3, 80);
        paneTable.getTable().setWidth(4, 100);
        paneTable.getTable().setWidth(5, 100);
        paneTable.getTable().setWidth(6, 100);
        FormatTextField.formatSearchField(txt_TimKiem, paneTable.getTable());
        this.removeAll();
        this.add(paneTable);
        this.validate();
        this.repaint();

        getTable().getTableHeader().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectAll();
                click++;
            }
        });
        getTable().addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                selectMany();
            }
        });

        getTable().addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    selectMany();
                }
            }
        });
    }

    private void selectAll() {
        if (click % 2 == 0) {
            ArrayList<SinhVien_Model> svms = new ArrayList<>();
            ArrayList<Integer> rows = new ArrayList<>();
            for (int i = 0; i < getTable().getRowCount(); i++) {
                svms.add(new SinhVien_Model(
                        String.valueOf(getTable().getModel().getValueAt(i, 1)),
                        String.valueOf(getTable().getModel().getValueAt(i, 2)),
                        String.valueOf(getTable().getModel().getValueAt(i, 3)),
                        String.valueOf(getTable().getModel().getValueAt(i, 4)),
                        String.valueOf(getTable().getModel().getValueAt(i, 5)),
                        String.valueOf(getTable().getModel().getValueAt(i, 6)),
                        String.valueOf(getTable().getModel().getValueAt(i, 7)),
                        String.valueOf(getTable().getModel().getValueAt(i, 8))
                ));
                rows.add(i);
            }
            listSelectedRows = svms;
            sinhVien_View_Impl.updateRowSelected(rows);
            sinhVien_View_Impl.updateTemporaryData(Constant.DELETE_SINHVIEN, svms);
        }
    }

    private void selectMany() {
        ArrayList<SinhVien_Model> svms = new ArrayList<>();
        ArrayList<Integer> rows = new ArrayList<>();
        for (int i = 0; i < getTable().getRowCount(); i++) {
            if (getTable().isSelectedRows(i, 0)) {
                svms.add(new SinhVien_Model(
                        String.valueOf(getTable().getModel().getValueAt(i, 1)),
                        String.valueOf(getTable().getModel().getValueAt(i, 2)),
                        String.valueOf(getTable().getModel().getValueAt(i, 3)),
                        String.valueOf(getTable().getModel().getValueAt(i, 4)),
                        String.valueOf(getTable().getModel().getValueAt(i, 5)),
                        String.valueOf(getTable().getModel().getValueAt(i, 6)),
                        String.valueOf(getTable().getModel().getValueAt(i, 7)),
                        String.valueOf(getTable().getModel().getValueAt(i, 8))
                ));
                rows.add(i);
            }
        }
        listSelectedRows = svms;
        sinhVien_View_Impl.updateRowSelected(rows);
        sinhVien_View_Impl.updateTemporaryData(Constant.DELETE_SINHVIEN, svms);
        boolean selectAll = rows.size() == getTable().getRowCount();
        if (selectAll && !getTable().getHeader().isClicked()) {
            getTable().getHeader().setMousePressed(true);
            getTable().getHeader().headerClick();
            getTable().getHeader().repaintCheckBox(getTable());
        } else if (!selectAll && getTable().getHeader().isClicked()) {
            getTable().getHeader().setMousePressed(true);
            getTable().getHeader().headerClick();
            getTable().getHeader().repaintCheckBox(getTable());
            rows.forEach((t) -> {
                getTable().setValueAt(true, t, 0);
            });
        }
    }

    public Object[][] convertList2Object(ArrayList<DSSinhVien_Model> dscb) {
        Object[][] ob = new Object[dscb.size()][4];
        for (int i = 0; i < ob.length; i++) {
            ob[i][0] = false;
            ob[i][1] = dscb.get(i).getMaSV();
            ob[i][2] = dscb.get(i).getTen();
            ob[i][3] = dscb.get(i).getMaRFID();
        }
        return ob;
    }

    public SinhVien_Model getValue() {
        try {
            int row = getTable().getSelectedRow();
            SinhVien_Model student_Model = new SinhVien_Model();
            if (row != -1) {
                student_Model.setMaSV(String.valueOf(paneTable.getTable().getModel().getValueAt(row, 1)));
                student_Model.setTen(String.valueOf(paneTable.getTable().getModel().getValueAt(row, 2)));
                student_Model.setEmail(String.valueOf(paneTable.getTable().getModel().getValueAt(row, 3)));
                student_Model.setLop(String.valueOf(paneTable.getTable().getModel().getValueAt(row, 4)));
                student_Model.setNganh(String.valueOf(paneTable.getTable().getModel().getValueAt(row, 5)));
                student_Model.setKhoa(String.valueOf(paneTable.getTable().getModel().getValueAt(row, 6)));
                student_Model.setNienKhoa(String.valueOf(paneTable.getTable().getModel().getValueAt(row, 7)));
                student_Model.setMaRFID(String.valueOf(paneTable.getTable().getModel().getValueAt(row, 8)));
                return student_Model;
            }
        } catch (NullPointerException ex) {
        }
        return null;
    }

    public void setDataTable(Object[][] data) {
        DefaultTableModel dm = (DefaultTableModel) paneTable.getTable().getModel();
        dm.getDataVector().removeAllElements();
        dm.fireTableDataChanged();
        dm.setDataVector(data, columnNames);
        paneTable.getTable().setModel(dm);
        paneTable.getTable().setCheckBox(0);
        paneTable.getTable().setWidth(0, 40);
//        paneTable.getTable().setWidth(1, 50);
//        paneTable.getTable().setWidth(2, 120);
//        paneTable.getTable().setWidth(3, 120);
//        paneTable.getTable().setWidth(4, 200);
//        paneTable.getTable().setWidth(5, 80);
    }

    public ArrayList<SinhVien_Model> getSelectedRow() {
        return listSelectedRows;
    }

    public void refreshTable() {
        sinhVienLoad = controller.load_SinhVien();
        setDataTable(SinhVien_Controller.array2Object(sinhVienLoad));
    }

    private ArrayList<SinhVien_Model> selectTypeView(String typeView) {
        ArrayList<SinhVien_Model> SinhVien_Models = new ArrayList<>();
        if (typeView.equals("Tất cả")) {
            SinhVien_Models = controller.load_SinhVien();
        }
        if (typeView.equals("Chưa đăng ký thẻ")) {
            SinhVien_Models = controller.load_SinhVienNoRFID();
        }
        if (typeView.equals("Đã đăng ký thẻ")) {
            SinhVien_Models = controller.load_SinhVienHaveRFID();
        }
        return SinhVien_Models;
    }

    // <editor-fold defaultstate="collapsed" desc="Get & SET">    
    public CustomTable.MyCustomTableModel getTableModel() {
        return paneTable.getCustomTableModel();
    }

    public PanelTable getPaneTable() {
        return paneTable;
    }

    public CustomTable getTable() {
        return paneTable.getTable();
    }

    public static SinhVien_Controller getController() {
        return controller;
    }

    public static void setController(SinhVien_Controller controller) {
        SinhVien_Table.controller = controller;
    }

    public ArrayList<SinhVien_Model> getSinhVien_Model() {
        return sinhVienLoad;
    }

    public void setSinhVien_Model(ArrayList<SinhVien_Model> sinhVien_Model) {
        SinhVien_Table.sinhVienLoad = sinhVien_Model;
    }

    public int getClick() {
        return click;
    }

    public void setClick(int click) {
        SinhVien_Table.click = click;
    }

    public boolean isCheckBox() {
        return checkBox;
    }

    public void setCheckBox(boolean checkBox) {
        this.checkBox = checkBox;
        paneTable.getTable().setCheckBox(0);
    }
// </editor-fold>  

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        pnl_CbxFilter = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cbxFilter = new javax.swing.JComboBox<>();
        pnl_Search = new javax.swing.JPanel();
        txt_TimKiem = new javax.swing.JTextField();
        btn_TimKiem = new javax.swing.JButton();

        pnl_CbxFilter.setOpaque(false);
        pnl_CbxFilter.setPreferredSize(new java.awt.Dimension(187, 45));
        pnl_CbxFilter.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 1, 12));

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel2.setText("Bộ lọc:");
        pnl_CbxFilter.add(jLabel2);

        cbxFilter.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        cbxFilter.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"Tất cả", "Đã có mã RFID", "Chưa có mã RFID"}));
        cbxFilter.setBorder(null);
        cbxFilter.setLightWeightPopupEnabled(false);
        cbxFilter.setOpaque(false);
        cbxFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbxFilterActionPerformed(evt);
            }
        });
        pnl_CbxFilter.add(cbxFilter);

        pnl_Search.setOpaque(false);
        pnl_Search.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        txt_TimKiem.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        txt_TimKiem.setForeground(new java.awt.Color(102, 102, 102));
        txt_TimKiem.setText("Nhập MSCB, Tên, Bộ môn, Khoa");
        txt_TimKiem.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)), javax.swing.BorderFactory.createEmptyBorder(0, 5, 0, 5)));
        txt_TimKiem.setPreferredSize(new java.awt.Dimension(220, 36));
        txt_TimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_TimKiemActionPerformed(evt);
            }
        });
        txt_TimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_TimKiemKeyReleased(evt);
            }
        });
        pnl_Search.add(txt_TimKiem);

        btn_TimKiem.setBackground(new java.awt.Color(102, 153, 255));
        btn_TimKiem.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btn_TimKiem.setForeground(new java.awt.Color(255, 255, 255));
        btn_TimKiem.setBorderPainted(false);
        btn_TimKiem.setContentAreaFilled(false);
        btn_TimKiem.setFocusPainted(false);
        btn_TimKiem.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        btn_TimKiem.setOpaque(true);
        btn_TimKiem.setPreferredSize(new java.awt.Dimension(40, 36));
        btn_TimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_TimKiemActionPerformed(evt);
            }
        });
        btn_TimKiem.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                btn_TimKiemKeyReleased(evt);
            }
        });
        pnl_Search.add(btn_TimKiem);

        setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 15, 0, 15));
        setLayout(new java.awt.GridLayout(1, 0));
    }// </editor-fold>                        

    private void cbxFilterActionPerformed(java.awt.event.ActionEvent evt) {
        if (initCombo) {
            paneTable.setSelectAll();
        }
    }

    public void refresh() {
        for (int i = 0; i < getTable().getRowCount(); i++) {
            getTableModel().removeRow(i);
        }
        CustomTable.MyCustomTableModel model = getTableModel();
        model.getDataVector().removeAllElements();
        ArrayList<SinhVien_Model> load_CanBo = getController().load_SinhVien();
        model.setDataVector(SinhVien_Controller.array2Object(load_CanBo));
        model.fireTableDataChanged();
        paneTable.getTable().setCheckBox(0);
        paneTable.getTable().setWidth(0, 40);
        paneTable.getTable().setWidth(1, 50);
        paneTable.getTable().setWidth(2, 120);
        paneTable.getTable().setWidth(3, 120);
        paneTable.getTable().setWidth(4, 200);
        paneTable.getTable().setWidth(5, 80);
    }

    private void txt_TimKiemKeyReleased(java.awt.event.KeyEvent evt) {

    }

    private void btn_TimKiemKeyReleased(java.awt.event.KeyEvent evt) {

    }

    private void btn_TimKiemActionPerformed(java.awt.event.ActionEvent evt) {
    }

    private void txt_TimKiemActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here:
    }

    // Variables declaration - do not modify                     
    private javax.swing.JButton btn_TimKiem;
    private javax.swing.JComboBox<String> cbxFilter;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel pnl_CbxFilter;
    private javax.swing.JPanel pnl_Search;
    private javax.swing.JTextField txt_TimKiem;
    // End of variables declaration                   

    public void execute() {
        paneTable.executeTable();
    }

}
