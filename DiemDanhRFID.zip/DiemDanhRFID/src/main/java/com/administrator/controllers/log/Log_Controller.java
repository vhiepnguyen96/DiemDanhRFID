/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.administrator.controllers.log;

import com.diemdanh.utils.common.LoggerUtilities;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author chuna
 */
public class Log_Controller {

    public Log_Controller() {

    }

    public Object[][] loadLogger() {
        String readLogger = LoggerUtilities.readLogger();
        String[] line = readLogger.split(";``");
        Object[][] oses = new Object[line.length][4];
        for (int i = 0; i < line.length; i++) {
            String[] col = line[i].trim().split(" ~~ ");
            if (col.length == 3) {
                String[] sub_col = col[0].split(" - "); //split Priority
                String priority = sub_col[0];
                String title = sub_col[1];
                String content = col[1];
                String time = col[2];
                List<String> asList = Arrays.asList(priority, title, content, time);
                for (int j = 0; j < asList.size(); j++) {
                    oses[i][j] = asList.get(j);
                }
            }
        }
        return oses;
    }

    public boolean clearLogger() {
        return LoggerUtilities.deleteLoggerFile();
    }
}
