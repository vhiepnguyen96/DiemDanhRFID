/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.administrator.views.log;

import com.administrator.controllers.log.Log_Controller;
import com.administrator.models.log.Log_Model;
import com.diemdanh.utils.other.component.Alert;
import com.diemdanh.utils.other.component.GradientButton;
import com.diemdanh.utils.common.Intent;
import com.diemdanh.utils.other.table.PanelTable;
import com.diemdanh.views.app.App_View;
import com.diemdanh.views.login.Login_View;

import javax.swing.*;
import javax.swing.table.TableColumnModel;
import java.awt.event.ActionEvent;

import static com.diemdanh.utils.common.SettingConfig.*;
import com.diemdanh.utils.common.LoggerUtilities;
import com.diemdanh.utils.constant.Constant;
import static com.diemdanh.utils.resources.Resources.*;
import java.awt.EventQueue;

/**
 * @author chuna
 */
public class Log_View extends javax.swing.JPanel {

    private String[] columnNames = new String[]{"Priority", "Title", "Content", "Time"};
    private final Log_Controller admin_Controller = new Log_Controller();
    private PanelTable table;

    public Log_Controller getAdmin_Controller() {
        return admin_Controller;
    }

    public Log_View() {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(App_View.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        }
        //</editor-fold>
        initComponents();
        createUI();
        EventQueue.invokeLater(() -> loadData());
    }

    public void showPanel() {
        if (loadData()) {
            table.executeTable();
        }
    }

    private void createUI() {
        btn_Reset = new GradientButton(bg_Color1, bg_Color2, fg_Color1, fg_Color2, "Xoá lịch sử làm việc", refresh_Icon);
        btn_Reset.addActionListener((ActionEvent e) -> {
            int select = Alert.showQuestionDialog(this, "Bạn muốn xoá lịch sử làm việc?\nHệ thống sẽ đăng xuất sau khi xoá lịch sử.", "Xoá lịch sử?");
            if (select == Alert.OK) {
                System.out.println("Failed.");
                if (admin_Controller.clearLogger()) {
                    EventQueue.invokeLater(() -> {
                        new Login_View().setVisible(true);
                        Login_View.app_View.dispose();
                        Intent.closeDialogBox();
                    });
                } else {
                    System.out.println("Failed.");
                }
            }
        });

        btn_Dangxuat = new GradientButton(bg_Color1, bg_Color2, fg_Color1, fg_Color2, "Đăng xuất", logout_Icon);
        btn_Dangxuat.addActionListener((e) -> {
            //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
            try {
                for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                    if ("Windows".equals(info.getName())) {
                        javax.swing.UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
                java.util.logging.Logger.getLogger(Login_View.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }
            //</editor-fold>
            EventQueue.invokeLater(() -> {
                LoggerUtilities.info(new Log_Model(Constant.LOGGER_LOGOUT, Login_View.getUser().getTaiKhoan() + " đăng xuất tài khoản thành công."));
                new Login_View().setVisible(true);
            });
            Intent.closeDialogBox();
            Login_View.app_View.dispose();
        });
        btn_Thoat = new GradientButton(bg_Color1, bg_Color2, fg_Color1, fg_Color2, "Thoát ứng dụng", exit_Icon);
        btn_Thoat.addActionListener((e) -> {
            LoggerUtilities.info(new Log_Model(Constant.LOGGER_CLOSE, Login_View.getUser().getTaiKhoan() + " đã thoát ứng dụng thành công."));
            System.exit(0);
        });
        pnl_AdvanceBar.add(btn_Reset);
        pnl_AdvanceBar.add(btn_Dangxuat);
        pnl_AdvanceBar.add(btn_Thoat);
    }

    private boolean loadData() {
        Object[][] loadLogger = admin_Controller.loadLogger();
        if (loadLogger != null) {
            table = new PanelTable(loadLogger, columnNames);
            table.getTable().setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
            Intent.setWidth(1000);
            Intent.replace(pnl_Table, table);
            Intent.setLocationRelativeTo(Login_View.getInstance());
            TableColumnModel colModel = table.getTable().getColumnModel();
            colModel.getColumn(0).setPreferredWidth(80);
            colModel.getColumn(1).setPreferredWidth(200);
            colModel.getColumn(2).setPreferredWidth(500);
            colModel.getColumn(3).setPreferredWidth(220);
            return true;
        }
        return false;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnl_Table = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        pnl_AdvanceBar = new javax.swing.JPanel();

        pnl_Table.setBackground(new java.awt.Color(255, 255, 255));
        pnl_Table.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 5, 15, 5));
        pnl_Table.setLayout(new java.awt.GridLayout(1, 0));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("Quản lý phiên đăng nhập");
        jLabel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 15, 10));
        jLabel2.setOpaque(true);

        pnl_AdvanceBar.setBackground(new java.awt.Color(204, 204, 255));
        pnl_AdvanceBar.setMinimumSize(new java.awt.Dimension(0, 45));
        pnl_AdvanceBar.setPreferredSize(new java.awt.Dimension(0, 45));
        pnl_AdvanceBar.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 10, 2));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnl_Table, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
            .addComponent(pnl_AdvanceBar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addGap(0, 0, 0)
                .addComponent(pnl_Table, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
                .addGap(0, 0, 0)
                .addComponent(pnl_AdvanceBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private GradientButton btn_Reset;
    private GradientButton btn_Dangxuat;
    private GradientButton btn_Thoat;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel pnl_AdvanceBar;
    private javax.swing.JPanel pnl_Table;
    // End of variables declaration//GEN-END:variables
}
