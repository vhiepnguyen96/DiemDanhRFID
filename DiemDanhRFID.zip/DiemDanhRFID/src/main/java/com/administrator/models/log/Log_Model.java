/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.administrator.models.log;

import com.diemdanh.utils.common.StringUtilities;
import java.sql.Timestamp;
import java.util.logging.Logger;

/**
 *
 * @author chuna
 */
public class Log_Model {

    private String title;
    private String content;

    public Log_Model() {
    }

    public Log_Model(String title, String content) {
        this.title = title;
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String noiDung) {
        this.content = noiDung;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public String toString() {
        String str = "";
        str += StringUtilities.unAccent(this.title.toUpperCase());
        str += " ~~ ";
        str += StringUtilities.unAccent(this.content);
        str += " ~~ ";
        str += new Timestamp(System.currentTimeMillis()).toGMTString();
        str += ";``";
        return str;
    }

}
